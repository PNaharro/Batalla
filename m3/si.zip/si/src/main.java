import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class main {
	static ArrayList listar_arma() {
		ArrayList<armas> armas = new ArrayList();
		String usuari = "root";
		String clau = "P@ssw0rd";
		String urlDades = "jdbc:mysql://localhost/br?serverTimezone=UTC";
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection(urlDades, usuari, clau);
			String query = "select * from weapons";
			Statement stmnt = conn.createStatement();
			ResultSet rs = stmnt.executeQuery(query);
			while (rs.next()) {
				armas n = new armas(rs.getString(3),rs.getInt(4),rs.getInt(5),rs.getInt(6),rs.getInt(7),rs.getInt(8));
				armas.add(n);
			}
		}catch(
				ClassNotFoundException ex)
		{
			System.out.println("No trobat el Driver MySQL per JDBC.");
		} catch (SQLException e) {
			System.out.println("Excepció del tipus SQL");
			e.printStackTrace();
		}
		return armas;
	}
	static ArrayList listar_personajes() {
		ArrayList<personajes> personajes = new ArrayList();
		String usuari = "root";
		String clau = "P@ssw0rd";
		String urlDades = "jdbc:mysql://localhost/br?serverTimezone=UTC";
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection(urlDades, usuari, clau);
			String query = "select w.nomWarrior,r.nom_raza,w.imgWarrior,r.vida,r.fuerza,r.agilidad,r.velocidad,r.defensa,r.puntos_que_da from warriors w inner join razas r on w.raza=r.id_raza;";
			Statement stmnt = conn.createStatement();
			ResultSet rs = stmnt.executeQuery(query);
			while (rs.next()) {
				personajes n = new personajes(rs.getString(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getInt(5),rs.getInt(6),rs.getInt(7),rs.getInt(8),rs.getInt(9));
				personajes.add(n);
			}
			return personajes;
		}catch(
				ClassNotFoundException ex)
		{
			System.out.println("No trobat el Driver MySQL per JDBC.");
		} catch (SQLException e) {
			System.out.println("Excepció del tipus SQL");
			e.printStackTrace();
		}
		return personajes;	
	}
	static personajes seleccionar(ArrayList personajes) {
		for (int i = 0;i<=personajes.size()-1;i++) {
			System.out.println(personajes.get(i));
		}
		return null;
		
	}
	public static void main(String[] args) {
		ArrayList<armas> armas = listar_arma();
		ArrayList<personajes> personajes = listar_personajes();
		String usuari = "root";
		String clau = "P@ssw0rd";
		String urlDades = "jdbc:mysql://localhost/br?serverTimezone=UTC";
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection(urlDades, usuari, clau);
			seleccionar(personajes);
			
			
		}catch(
				ClassNotFoundException ex)
		{
			System.out.println("No trobat el Driver MySQL per JDBC.");
		} catch (SQLException e) {
			System.out.println("Excepció del tipus SQL");
			e.printStackTrace();
		}
	}/*main*/
	
}
