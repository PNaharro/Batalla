
public class usuario {
	private String nombre;
	private int puntos;
	private personajes personaje;
	public usuario(String nombre,personajes personaje) {
		super();
		this.nombre = nombre;
		this.personaje = personaje;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getPuntos() {
		return puntos;
	}
	public void setPuntos(int puntos) {
		this.puntos = puntos;
	}
	public personajes getPersonaje() {
		return personaje;
	}
	public void setPersonaje(personajes personaje) {
		this.personaje = personaje;
	}
	
}
