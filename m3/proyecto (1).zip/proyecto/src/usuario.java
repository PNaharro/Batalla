
public class usuario {
	private String nombre;
	private int puntos;
	private personajes personaje;
}
