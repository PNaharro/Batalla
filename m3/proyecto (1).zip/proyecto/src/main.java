import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class main {
	public static void main(String[] args) {
		ArrayList<armas> armas = new ArrayList();
		ArrayList<personajes> personajes = new ArrayList();
		String usuari = "root";
		String clau = "1234";
		String urlDades = "jdbc:mysql://localhost/br?serverTimezone=UTC";
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver carregat correctament");
			Connection conn = DriverManager.getConnection(urlDades, usuari, clau);
			System.out.println("conexió creada correctament");
			String query = "select * from weapons";
			Statement stmnt = conn.createStatement();
			ResultSet rs = stmnt.executeQuery(query);
			while (rs.next()) {
				armas n = new armas(rs.getString(3),rs.getInt(4),rs.getInt(5),rs.getInt(6),rs.getInt(7),rs.getInt(8));
				armas.add(n);
			}
			System.out.println(armas);
			query = "select w.nomWarrior,r.nom_raza,w.imgWarrior,r.vida,r.fuerza,r.agilidad,r.velocidad,r.defensa,r.puntos_que_da from warriors w inner join razas r on w.raza=r.id_raza;";
			stmnt = conn.createStatement();
			rs = stmnt.executeQuery(query);
			while (rs.next()) {
				personajes n = new personajes(rs.getString(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getInt(5),rs.getInt(6),rs.getInt(7),rs.getInt(8),rs.getInt(9));
				personajes.add(n);
			}
			System.out.println(personajes);
		}catch(
				ClassNotFoundException ex)
		{
			System.out.println("No trobat el Driver MySQL per JDBC.");
		} catch (SQLException e) {
			System.out.println("Excepció del tipus SQL");
			e.printStackTrace();
		}
	}/*main*/
	
}
