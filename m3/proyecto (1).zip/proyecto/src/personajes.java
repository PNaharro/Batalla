

public class personajes {
	private String name,raza,img;
	private int vida,fuerza,agilidad,velociadad,defensa,puntos;
	private armas arma;
	public personajes(String name, String raza,String img, int vida, int fuerza, int agilidad, int velociadad, int defensa,int puntos) {
		super();
		this.name = name;
		this.raza = raza;
		this.img = img;
		this.vida = vida;
		this.fuerza = fuerza;
		this.agilidad = agilidad;
		this.velociadad = velociadad;
		this.defensa = defensa;
		this.puntos = puntos;
	}
	
	public armas getArma() {
		return arma;
	}
	public void setArma(armas arma) {
		this.arma = arma;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRaza() {
		return raza;
	}
	public void setRaza(String raza) {
		this.raza = raza;
	}
	public int getVida() {
		return vida;
	}
	public void setVida(int vida) {
		this.vida = vida;
	}
	public int getFuerza() {
		return fuerza;
	}
	public void setFuerza(int fuerza) {
		this.fuerza = fuerza;
	}
	public int getAgilidad() {
		return agilidad;
	}
	public void setAgilidad(int agilidad) {
		this.agilidad = agilidad;
	}
	public int getVelociadad() {
		return velociadad;
	}
	public void setVelociadad(int velociadad) {
		this.velociadad = velociadad;
	}
	public int getDefensa() {
		return defensa;
	}
	public void setDefensa(int defensa) {
		this.defensa = defensa;
	}

	@Override
	public String toString() {
		return "personajes [name=" + name + ", raza=" + raza + ", img=" + img + ", vida=" + vida + ", fuerza=" + fuerza
				+ ", agilidad=" + agilidad + ", velociadad=" + velociadad + ", defensa=" + defensa + ", arma=" + arma
				+ "]";
	}
	
	
	
}
