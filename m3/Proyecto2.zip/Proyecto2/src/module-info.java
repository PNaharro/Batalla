/**
 * 
 */
/**
 * @author diego
 *
 */
module Proyecto2 {
	requires java.desktop;
	requires java.sql;
}