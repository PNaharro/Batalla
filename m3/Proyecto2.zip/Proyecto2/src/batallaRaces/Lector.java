package batallaRaces;

import java.util.Scanner;

public class Lector {
	public static String input(){
		Scanner sc = new Scanner(System.in);
		String text = sc.nextLine();
		return text;
	}
	
}
