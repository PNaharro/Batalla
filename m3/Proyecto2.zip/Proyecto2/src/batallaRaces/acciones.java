package batallaRaces;
public interface acciones {
	void equipar(armas arma);
}
